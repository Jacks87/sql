﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace InheritanceEncapsulationAndPolymorphism
{
    public partial class FormCars : Form
    {
        private readonly List<Car> vehicles = new List<Car>();

        public FormCars()
        {
            InitializeComponent();

            // seed the vehicle-type dropdown
            cmbVehicleType.Items.AddRange(new[] {
                "Car", "Electric Car", "Gas Car", "Hybrid Car"
            });
            cmbVehicleType.SelectedIndex = 0;
        }

        private void cmbVehicleType_SelectedIndexChanged(object sender, EventArgs e)
        {
            var type = cmbVehicleType.SelectedItem?.ToString();
            bool isElec = type == "Electric Car";
            bool isGas = type == "Gas Car";
            bool isHybrid = type == "Hybrid Car";

            lblBattery.Visible = txtBattery.Visible = isElec || isHybrid;
            lblFuelTank.Visible = txtFuelTank.Visible = isGas || isHybrid;
        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            string make = txtMake.Text.Trim();
            string model = txtModel.Text.Trim();
            if (!int.TryParse(txtYear.Text.Trim(), out int year))
            {
                MessageBox.Show("Please enter a valid year.");
                return;
            }
            string color = txtColor.Text.Trim();
            if (!decimal.TryParse(txtPrice.Text.Trim(), out decimal price))
            {
                MessageBox.Show("Please enter a valid price.");
                return;
            }

            Car vehicle;
            var type = cmbVehicleType.SelectedItem?.ToString();

            if (type == "Electric Car")
            {
                if (!double.TryParse(txtBattery.Text.Trim(), out double bat))
                {
                    MessageBox.Show("Enter a valid battery capacity.");
                    return;
                }
                vehicle = new ElectricCar
                {
                    Make = make,
                    Model = model,
                    Year = year,
                    Color = color,
                    Price = price,
                    BatteryCapacity = bat
                };
            }
            else if (type == "Gas Car")
            {
                if (!double.TryParse(txtFuelTank.Text.Trim(), out double tank))
                {
                    MessageBox.Show("Enter a valid tank capacity.");
                    return;
                }
                vehicle = new GasCar
                {
                    Make = make,
                    Model = model,
                    Year = year,
                    Color = color,
                    Price = price,
                    FuelTankCapacity = tank
                };
            }
            else if (type == "Hybrid Car")
            {
                if (!double.TryParse(txtBattery.Text.Trim(), out double bat) ||
                    !double.TryParse(txtFuelTank.Text.Trim(), out double tank))
                {
                    MessageBox.Show("Enter valid battery & tank capacities.");
                    return;
                }
                vehicle = new HybridCar
                {
                    Make = make,
                    Model = model,
                    Year = year,
                    Color = color,
                    Price = price,
                    BatteryCapacity = bat,
                    FuelTankCapacity = tank
                };
            }
            else
            {
                vehicle = new Car
                {
                    Make = make,
                    Model = model,
                    Year = year,
                    Color = color,
                    Price = price
                };
            }

            vehicles.Add(vehicle);
            lstCars.Items.Add(vehicle.DisplayInfo());
        }

        private void carsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.carsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.carInventoryDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.carsTableAdapter.Fill(this.carInventoryDataSet.Cars);

        }

        private void ShowsCustomersButton_Click(object sender, EventArgs e)
        {
            FormCustomers customerForm = new FormCustomers();
            customerForm.Show();
        }

        private void ShowOrdersButton_Click(object sender, EventArgs e)
        {
            FormOrders orderForm = new FormOrders();
            orderForm.Show();
        }

        private void filterByMakeButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.carsTableAdapter.FillByMake(this.carInventoryDataSet.Cars, makeTextBox.Text);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error filtering cars: " + ex.Message);
            }
        }
    }
}



