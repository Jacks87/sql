﻿using System.Windows.Forms;
using System;
using System;
using System.Windows.Forms;

namespace InheritanceEncapsulationAndPolymorphism
{
    public partial class FormOrders : Form
    { // <-- Class FormOrders starts HERE
      // (Constructor FormOrders() might be here - that's okay)

        private void FormOrders_Load(object sender, EventArgs e)
        {
            try
            {
                this.ordersTableAdapter.Fill(this.carInventoryDataSet.Orders);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error loading orders: " + ex.Message, "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Check the row count AFTER trying to fill
            MessageBox.Show($"Orders table has {this.carInventoryDataSet.Orders.Rows.Count} rows after Fill.");
        }
    }
}
