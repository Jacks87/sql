﻿using System;

namespace InheritanceEncapsulationAndPolymorphism
{
    // Base Car class with 5 properties and a virtual DisplayInfo method
    public class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }
        public decimal Price { get; set; }

        public virtual string DisplayInfo() =>
            $"{Year} {Make} {Model} — {Color} @ ${Price}";
    }

    // ElectricCar adds BatteryCapacity and overrides DisplayInfo
    public class ElectricCar : Car
    {
        public double BatteryCapacity { get; set; }
        public override string DisplayInfo() =>
            base.DisplayInfo() + $" | Battery: {BatteryCapacity} kWh";
    }

    // GasCar adds FuelTankCapacity and overrides DisplayInfo
    public class GasCar : Car
    {
        public double FuelTankCapacity { get; set; }
        public override string DisplayInfo() =>
            base.DisplayInfo() + $" | Tank: {FuelTankCapacity} gal";
    }

    // HybridCar adds both battery and fuel and overrides DisplayInfo
    public class HybridCar : Car
    {
        public double BatteryCapacity { get; set; }
        public double FuelTankCapacity { get; set; }
        public override string DisplayInfo() =>
            base.DisplayInfo()
            + $" | Battery: {BatteryCapacity} kWh"
            + $" | Tank: {FuelTankCapacity} gal";
    }
}
