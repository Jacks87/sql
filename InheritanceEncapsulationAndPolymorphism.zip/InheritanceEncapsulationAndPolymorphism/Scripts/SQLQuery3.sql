﻿-- create the two tables
CREATE TABLE Customers (
  CustomerID   INT IDENTITY(1,1) PRIMARY KEY,
  CustomerName NVARCHAR(100) NOT NULL,
  Email        NVARCHAR(100) NOT NULL
);

CREATE TABLE Orders (
  OrderID    INT IDENTITY(1,1) PRIMARY KEY,
  OrderDate  DATE NOT NULL,
  CustomerID INT NOT NULL
    FOREIGN KEY REFERENCES Customers(CustomerID)
);
INSERT INTO Customers (CustomerName, Email) VALUES
  ('Alice','alice@example.com'),
  ('Bob','bob@example.com'),
  ('Cara','cara@example.com');

INSERT INTO Orders (OrderDate, CustomerID) VALUES
  ('2025-04-20',1),
  ('2025-04-21',1),
  ('2025-04-22',2);
