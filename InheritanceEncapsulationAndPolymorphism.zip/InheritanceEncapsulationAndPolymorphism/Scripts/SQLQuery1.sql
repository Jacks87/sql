﻿CREATE TABLE Cars (
  CarID   INT IDENTITY(1,1) PRIMARY KEY,
  Make    NVARCHAR(50) NOT NULL,
  Model   NVARCHAR(50) NOT NULL,
  Year    INT            NOT NULL,
  Price   DECIMAL(9,2)   NULL
);

INSERT INTO Cars (Make, Model, Year, Price) VALUES
  ('Toyota', 'Corolla', 2020, 20000.00),
  ('Honda',  'Civic',   2019, 18000.00),
  ('Ford',   'Focus',   2018, 17000.00);
