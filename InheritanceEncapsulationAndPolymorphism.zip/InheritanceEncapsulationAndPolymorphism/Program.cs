﻿using System;
using System.Windows.Forms;

namespace InheritanceEncapsulationAndPolymorphism
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Launch your input data form by default
            Application.Run(new FormCars());
        }
    }
}

