﻿using System;
using System.Windows.Forms;

namespace InheritanceEncapsulationAndPolymorphism
{
    public partial class FormCustomers : Form
    {
        public FormCustomers()
        {
            InitializeComponent();
        }

        private void FormCustomers_Load(object sender, EventArgs e)
        {
            // Load the Customers table into the grid
            this.customersTableAdapter.Fill(this.carInventoryDataSet.Customers);
        }
    }
}


