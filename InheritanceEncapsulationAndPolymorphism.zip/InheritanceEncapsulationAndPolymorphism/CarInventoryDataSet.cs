﻿namespace InheritanceEncapsulationAndPolymorphism
{


    partial class CarInventoryDataSet
    {
    }
}
